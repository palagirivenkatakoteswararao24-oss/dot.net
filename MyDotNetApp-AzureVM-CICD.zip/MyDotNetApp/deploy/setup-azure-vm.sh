#!/usr/bin/env bash
# Run this script ONCE on a fresh Ubuntu 22.04/24.04 Azure VM as root or with sudo.
set -euo pipefail

APP_DIR="/var/www/mydotnetapp"
SERVICE_FILE="/etc/systemd/system/mydotnetapp.service"

apt-get update
apt-get install -y nginx

id www-data >/dev/null
mkdir -p "$APP_DIR"
chown -R www-data:www-data "$APP_DIR"

cat > "$SERVICE_FILE" <<'SERVICE'
[Unit]
Description=My .NET DevOps App
After=network.target

[Service]
WorkingDirectory=/var/www/mydotnetapp
ExecStart=/var/www/mydotnetapp/MyDotNetApp
Restart=always
RestartSec=5
KillSignal=SIGINT
SyslogIdentifier=mydotnetapp
User=www-data
Environment=ASPNETCORE_ENVIRONMENT=Production
Environment=ASPNETCORE_URLS=http://127.0.0.1:5000

[Install]
WantedBy=multi-user.target
SERVICE

cat > /etc/nginx/sites-available/mydotnetapp <<'NGINX'
server {
    listen 80;
    server_name _;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
NGINX

ln -sfn /etc/nginx/sites-available/mydotnetapp /etc/nginx/sites-enabled/mydotnetapp
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl daemon-reload
systemctl enable mydotnetapp
systemctl enable nginx
systemctl restart nginx

echo "VM preparation completed. Push to GitHub main to deploy the app."
echo "After first successful GitHub Actions deployment, check: systemctl status mydotnetapp"
