# My .NET DevOps App

A beginner-friendly ASP.NET Core Razor Pages dashboard with GitHub Actions CI/CD deployment to an Ubuntu Azure VM.

## Technology
- .NET 10 / C#
- ASP.NET Core Razor Pages
- xUnit unit tests
- GitHub Actions
- Ubuntu Azure VM + Nginx + systemd

## 1. Run locally

Install the .NET 10 SDK from https://dotnet.microsoft.com/download/dotnet/10.0

From the repository root:

```bash
dotnet restore MyDotNetApp.sln
dotnet build MyDotNetApp.sln
dotnet test MyDotNetApp.sln
dotnet run --project MyDotNetApp
```

Open the local URL printed in the terminal. Check the health endpoint at `/health`.

## 2. Create a GitHub repository and push

Create an empty GitHub repository named `MyDotNetApp` (do not initialize it with a README if you already have this project).

```bash
git init
git add .
git commit -m "Initial .NET app with CI/CD"
git branch -M main
git remote add origin https://github.com/YOUR-GITHUB-USERNAME/MyDotNetApp.git
git push -u origin main
```

Replace `YOUR-GITHUB-USERNAME` with your GitHub username.

## 3. Create an Azure VM

Create an Ubuntu 22.04 or 24.04 LTS VM. Use SSH key authentication. In the VM's Network Security Group, allow:
- TCP 22 from your trusted public IP only (SSH administration).
- TCP 80 from the internet (HTTP website).
- TCP 443 from the internet only if/when you configure HTTPS.

Do not expose port 5000 publicly. The app listens on localhost only; Nginx receives public web traffic on port 80.

## 4. Prepare the VM once

Connect to the VM using SSH, upload or paste `deploy/setup-azure-vm.sh`, then run:

```bash
chmod +x setup-azure-vm.sh
sudo ./setup-azure-vm.sh
```

This installs Nginx and configures a systemd service. It is safe to run before the first deployment; the service starts after the first release has been copied.

## 5. Add GitHub Actions secrets

In GitHub, open your repository:
Settings -> Secrets and variables -> Actions -> New repository secret.

Create these three secrets:

| Secret name | Value |
|---|---|
| `AZURE_VM_HOST` | VM public IP address or DNS name |
| `AZURE_VM_USER` | Linux SSH username, for example `azureuser` |
| `AZURE_VM_SSH_PRIVATE_KEY` | Full private SSH key matching the public key installed for that VM user |

The SSH user must be allowed to run the deployment commands with sudo. For a dedicated deployment account, configure narrowly scoped sudo permissions for the required commands rather than granting unrestricted access. Never commit private keys or passwords to GitHub.

The workflow uses SSH to copy the package, then runs sudo commands on the VM to install it and restart the service. For a simple learning lab, a VM administrator account may be used; for production, use a dedicated deployment identity and least-privilege sudo policy.

## 6. Run CI/CD

Push a change to the `main` branch. In GitHub, open Actions and select `.NET CI and CD to Azure VM`.

CI runs restore, build, and unit tests. If successful, it publishes a self-contained Linux x64 package. CD then copies the package to the VM and restarts the `mydotnetapp` service. Pull requests run CI but do not deploy.

## 7. Verify deployment

Open:

```text
http://YOUR-AZURE-VM-PUBLIC-IP/
http://YOUR-AZURE-VM-PUBLIC-IP/health
```

On the VM, inspect the service:

```bash
sudo systemctl status mydotnetapp
sudo journalctl -u mydotnetapp -f
sudo nginx -t
```

## 8. Common troubleshooting

- **SSH fails:** confirm port 22 is allowed from the GitHub-hosted runner (or use a self-hosted runner for fixed-IP/locked-down environments), username is correct, and private key matches the VM public key.
- **Permission denied during deployment:** confirm the SSH user can create/copy the package and run the deployment's sudo commands.
- **Website does not open:** confirm NSG allows TCP 80, Nginx is active (`sudo systemctl status nginx`), and the app service is active.
- **Service fails:** check `sudo journalctl -u mydotnetapp -n 100 --no-pager`.
- **Wrong VM architecture:** this workflow publishes `linux-x64`; use an x64 Ubuntu VM.
- **HTTPS:** configure a DNS name and TLS certificate (for example, with Let's Encrypt) before using this for a public production site.

## Project structure

```text
MyDotNetApp/
├── .github/workflows/ci-cd.yml
├── deploy/setup-azure-vm.sh
├── MyDotNetApp.sln
├── MyDotNetApp/
│   ├── Pages/
│   ├── Services/
│   ├── wwwroot/
│   ├── Program.cs
│   └── MyDotNetApp.csproj
└── MyDotNetApp.Tests/
```

## Important
The dashboard's deployment counts are demonstration values. They are not connected to GitHub's live workflow API. The `/health` route is a real health response from the running application. This starter workflow uses GitHub-hosted runners and SSH; for production environments, consider a self-hosted runner or a private deployment network, protected GitHub environments, restricted SSH access, TLS, and a least-privilege deployment account.
