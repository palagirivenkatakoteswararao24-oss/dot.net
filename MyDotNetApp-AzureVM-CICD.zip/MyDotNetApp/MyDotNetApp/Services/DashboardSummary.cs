namespace MyDotNetApp.Services;

public class DashboardSummary
{
    public int ActiveDeployments => 3;
    public int SuccessfulBuilds => 128;
    public int FailedBuilds => 4;
    public string EnvironmentName => "Azure VM";

    public string BuildSuccessRateLabel()
    {
        var total = SuccessfulBuilds + FailedBuilds;
        var percentage = total == 0 ? 0 : (double)SuccessfulBuilds / total * 100;
        return $"{percentage:0.0}%";
    }
}
