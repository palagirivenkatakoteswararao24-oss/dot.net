using MyDotNetApp.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddRazorPages();
builder.Services.AddSingleton<DashboardSummary>();

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();

app.MapRazorPages();
app.MapGet("/health", () => Results.Ok(new
{
    status = "Healthy",
    application = "My .NET DevOps App",
    timestampUtc = DateTime.UtcNow
}));

app.Run();
