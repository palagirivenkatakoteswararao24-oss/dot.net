// Small client-side confirmation that the dashboard JavaScript is loaded.
document.addEventListener("DOMContentLoaded", () => {
    console.info("My .NET DevOps App dashboard loaded.");
});
