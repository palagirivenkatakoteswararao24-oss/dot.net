using Microsoft.AspNetCore.Mvc.RazorPages;
using MyDotNetApp.Services;

namespace MyDotNetApp.Pages;

public class IndexModel : PageModel
{
    public DashboardSummary Summary { get; }

    public IndexModel(DashboardSummary summary)
    {
        Summary = summary;
    }

    public void OnGet()
    {
    }
}
