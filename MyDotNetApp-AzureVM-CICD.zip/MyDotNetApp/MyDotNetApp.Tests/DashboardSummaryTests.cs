using Xunit;
using MyDotNetApp.Services;

namespace MyDotNetApp.Tests;

public class DashboardSummaryTests
{
    [Fact]
    public void BuildSuccessRateLabel_ReturnsExpectedPercentage()
    {
        var summary = new DashboardSummary();
        Assert.Equal("97.0%", summary.BuildSuccessRateLabel());
    }

    [Fact]
    public void EnvironmentName_IsAzureVm()
    {
        var summary = new DashboardSummary();
        Assert.Equal("Azure VM", summary.EnvironmentName);
    }
}
